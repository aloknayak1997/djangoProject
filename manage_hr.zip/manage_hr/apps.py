from django.apps import AppConfig


class ManageHrConfig(AppConfig):
    name = 'manage_hr'
